// Ejemplopilaestatica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Pila.h"
#include "TipoDato.h"

void main()
{

	
}

