#include "stdafx.h"
#include "iostream"
using namespace std;

int multiplo(int a, int b)
{ int status;
  if(a > b)
  {
     if(a % b==0)
		 status=1;
  }
  else
	  status=0;
  return status;
}

void main()
{
	int a,b;
	cout<<"Valor 1:"; cin>>a;
	cout<<"Valor 2:"; cin>>b;
	int v=multiplo(a,b);
	cout<<v;
}

