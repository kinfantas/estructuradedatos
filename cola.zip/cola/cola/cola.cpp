// cola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include <iostream>
#include "Colae.h"

#define MAX 100

using namespace std;

void main()
{
	Colae cola;
	int Valor;
	for (int j=1;j<10;j++)
		if (!cola.Encolar(j)) 
			cola.mostrar();
		else
			cout<<"Error";
	cout<<endl<<"Desencolar"<<endl;
	if (!cola.Desencolar())
		cola.mostrar();
	else
		cout<<"Error";
	if (!cola.PrimeroCola(Valor))
		cout<<"Valor: "<<Valor;
	getch();
}